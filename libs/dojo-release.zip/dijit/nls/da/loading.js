//>>built
define("dijit/nls/da/loading",({loadingState:"Indlæser...",errorState:"Der er opstået en fejl"}));
